var i = 0;
function mystart(){
    i++;
    postMessage(i);
    setTimeout("mystart()", 1000);
}
mystart();