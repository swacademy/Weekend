window.addEventListener("load", setup, false);
function setup(){
    var array = document.getElementsByTagName("button");
    array[0].addEventListener("click", redChange, false);
    array[1].addEventListener("click", blueChange, false);
}
function redChange(){
    document.body.style.backgroundColor = "red";
}
function blueChange(){
    document.body.style.backgroundColor = "blue";
}