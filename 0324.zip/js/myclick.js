window.addEventListener('load', setup, false);  //false:bubble up, true : cascade down
function setup(){
    var mybutton = document.getElementById('mybutton');
    mybutton.addEventListener('click', myChange);
}
function myChange(){
    var body = this.parentNode;
    body.style.backgroundColor = 'yellow';
}