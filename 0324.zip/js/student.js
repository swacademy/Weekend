var Student = function(na, a){
    this.name = na;
    this.age = a;
}