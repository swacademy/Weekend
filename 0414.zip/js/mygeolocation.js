window.addEventListener('load', setup, false);

function setup(){
    if(window.navigator.geolocation){
        navigator.geolocation.getCurrentPosition(mycallback);
    }else{
        alert("귀하의 브라우저는 지원되지 않습니다.");
    }
}

function mycallback(position){
    console.log(position);
    var latitude = position.coords.latitude;
    var longitude = position.coords.longitude;
    document.querySelector('#latitude').innerHTML = latitude;
    document.querySelector('#longitude').innerHTML = longitude;
    document.querySelector('#time').innerHTML = new Date().toLocaleTimeString();
}