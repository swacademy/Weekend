window.addEventListener('load', setup, false);
function setup(){
    var button = document.getElementsByTagName('input')[0];
    button.addEventListener('click', myclick, false);
}
function myclick(){
    var body = document.getElementsByTagName('body')[0];
    body.style.backgroundColor = 'red';
}