window.addEventListener('load', setup, false);

var capcher = null;
function setup(){
    capcher = document.getElementById('contents');
    capcher.addEventListener('dragover', MyOver, false);
    capcher.addEventListener('drop', MyDrop, false);
}
function MyOver(evt){
    evt.preventDefault();
}
var file = null;
function MyDrop(evt){
    evt.preventDefault();
    if(document.getElementById('contents').childNodes.length){
        document.getElementById('contents').
              removeChild(document.getElementById('contents').firstChild);
    }
    file = evt.dataTransfer.files[0];
    var str = 'File Info : ' + file.name + ' (' + 
                  file.size.toLocaleString() + 'bytes, ' +
                  file.type + ')';
    document.getElementById('fileinfo').innerHTML = str;
    if(isPreview(file)){  //미리 보기 가능한 파일이라면
        filePreview();
    }else{
        document.getElementById('contents').innerHTML = "<span style='color:red'>" +
                                                                                   "미리보기 지원 파일이 아닙니다." +
                                                                                   "</span>";
    }
}
function filePreview(){
    var fr = new FileReader();
    fr.addEventListener('error', function(err){
        document.getElementById('contents').innerHTML = 
                 "<span style='color:red'>" + err + "</span>";
    },false);
    fr.addEventListener('load', function(){
        if(file.type.match(/^image/g)){   //이미지 파일이라면
            var img = document.createElement('img');
            img.setAttribute('src', fr.result);
            document.getElementById('contents').appendChild(img);
        }else if(file.type.match(/^video/g)){   //동영상 파일이라면
            var video = document.createElement('video');
            video.setAttribute('src', fr.result);
            video.setAttribute('controls', 'controls');
            video.setAttribute('autoplay', 'autoplay');
            document.getElementById('contents').appendChild(video);
        }else if(file.type.match(/^audio/g)){   //사운드 파일이라면
            var audio = document.createElement('audio');
            audio.setAttribute('src', fr.result);
            audio.setAttribute('controls', 'controls');
            audio.setAttribute('autoplay', 'autoplay');
            document.getElementById('contents').appendChild(audio);
        }else{   //text파일이라면
            var str = fr.result;
            str = str.replace(/</g, '&lt;');
            str = str.replace(/>/g, '&gt;');
            str = str.replace(/\r\n/g, '<br />');
            document.getElementById('contents').innerHTML = str;
        }
    }, false);
    if(file.type.match(/^text/g)) fr.readAsText(file);
    else fr.readAsDataURL(file);
}


function isPreview(file){
    var flag = false;
    if(file.type.match(/^text/g)) flag = true;
    else if(file.name.substring(file.name.lastIndexOf(".")) == '.html') flag = true;
    else if(file.name.substring(file.name.lastIndexOf(".")) == '.js') flag = true;
    else if(file.name.substring(file.name.lastIndexOf(".")) == '.css') flag = true;
    else if(file.type.match(/^image/g)) flag = true;
    else if(file.type.match(/^video/g)) flag = true;
    else if(file.type.match(/^audio/g)) flag = true;
    else flag = false;
    return flag;
}